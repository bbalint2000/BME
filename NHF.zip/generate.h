#ifndef NHF_GENERATE_H
#define NHF_GENERATE_H
#include "datastruct.h"


void mine_gen(mainstruct level);
void set_userBoard(mainstruct level);



#endif //NHF_GENERATE_H
