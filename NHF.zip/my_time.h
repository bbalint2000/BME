#ifndef NHF_MY_TIME_H
#define NHF_MY_TIME_H
#include <time.h>
#include "datastruct.h"

Time time_now(clock_t start_time);
int time_in_sec(mainstruct level);



#endif //NHF_MY_TIME_H
