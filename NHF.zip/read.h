#ifndef NHF_READ_H
#define NHF_READ_H

#include "datastruct.h"




char* txt_name_scan(void);
mainstruct read_in(void);
type choose(void);
koord data_in(void);



#endif //NHF_READ_H
